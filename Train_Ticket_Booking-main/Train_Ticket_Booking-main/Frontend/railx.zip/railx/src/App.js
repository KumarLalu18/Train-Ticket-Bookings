import React from 'react';

import './App.css';


import {Route, Routes, useLocation, useNavigate} from 'react-router-dom';
import ViewTrain from './component/Train/ViewTrain';
import AddTrain from './component/Train/AddTrain';
import SearchTrain from './component/Train/SearchTrain';
import HomePage from './component/HomePage/HomePage';
import CreateBooking from './component/Booking/CreateBooking';
import Signup from './component/Signup/Signup';
import Login from './component/Login/Login';
import ViewBooking from './component/Booking/ViewBooking';

import BookingDetails from './component/Booking/BookingDetails';
import GenerateTicket from './component/Ticket/GenerateTicket';
import ViewTicket from './component/Ticket/ViewTicket';
import About from './component/HomePage/About';
import Bookings from './component/Train/Bookings';
import PassengerList from './component/Train/PassengerList';
import Footer from './component/HomePage/Footer';
import MyReservations from './component/Ticket/MyReservations';

function App() {

  const location = useLocation();
  const navigate=useNavigate();
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<HomePage/>}/>
        <Route path='/viewTrain' element={<ViewTrain/>}/>

        <Route path='/addTrain' element={<AddTrain/>}/>
        <Route path='/searchTrain' element={<SearchTrain/>}/>
        <Route path='/home' element={<HomePage/>}/>
        <Route path='/createBooking' element={<CreateBooking/>}/>
        <Route path='/signup' element={<Signup/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/viewBooking' element={<ViewBooking/>}/>

        <Route path='/booking-details' element={<BookingDetails/>}/>
        <Route path='/generateTicket' element={<GenerateTicket/>}/>
        <Route path='/viewTicket' element={<ViewTicket/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/bookings' element={<Bookings/>}/>
        <Route path='/myReservations' element={<MyReservations/>}/>
        <Route path='/passengerList/:id' element={<PassengerList location={location} />} />

      </Routes>
     <Footer/>
    </div>
  );
}

export default App;