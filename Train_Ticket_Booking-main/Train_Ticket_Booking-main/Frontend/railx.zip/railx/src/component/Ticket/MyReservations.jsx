import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import LoginNavbar from '../LoginNavbar/LoginNavbar';
// import './MyReservations.css'; // Import the CSS file

const MyReservations = () => {
  const [tickets, setTickets] = useState([]);
  const { state } = useLocation();
  const navigate = useNavigate(); // Add this line

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));

    if (!user) {
      navigate('/login');
      return;
    }

    if (user.role!== 'User') {
      navigate('/login');
    }

    if (user) {
      const userId = user.id;

      axios.get(`http://localhost:8080/ticket/user/${userId}`)
       .then(response => {
          setTickets(response.data);
        })
       .catch(error => console.error('Error fetching tickets:', error));
    }
  }, []);

  return (
    <>
    <LoginNavbar/>
    <div className="reservations-container">
      <h2>My Reservations</h2>
      {tickets.length? (
        <table className='reservations-table'>
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>Train Name</th>
              <th>Source</th>
              <th>Destination</th>
              <th>Journey Date</th>
              <th>Total Tickets</th>
              <th>Total Fare</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map(ticket => (
              <tr key={ticket.bookingId}>
                <td>{ticket.booking.bookingId}</td>
                <td>{ticket.booking.train.trainName}</td>
                <td>{ticket.booking.train.source}</td>
                <td>{ticket.booking.train.destination}</td>
                <td>{ticket.booking.train.journeyDate}</td>
                <td>{ticket.booking.totalTickets}</td>
                <td>{ticket.booking.totalFare}</td>
                <td>Reserved</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No reservations found.</p>
      )}
    </div>
    </>
  );
};

export default MyReservations;