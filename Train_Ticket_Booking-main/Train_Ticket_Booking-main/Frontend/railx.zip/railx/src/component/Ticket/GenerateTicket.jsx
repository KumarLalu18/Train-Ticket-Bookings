import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./GenerateTicket.css";
import LoginNavbar from "../LoginNavbar/LoginNavbar";

function GenerateTicket() {
  const [bookingId, setBookingId] = useState("");
  const [booking, setBooking] = useState("");
  const [ticket, setTicket] = useState({});
  const [ticketId, setTicketId] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const bookingString = localStorage.getItem("booking");
    console.log(bookingString);

    const userString = localStorage.getItem("user");
    if (!userString) {
      navigate("/login");
      return;
    }
    const user = JSON.parse(userString);
    if (user.role !== "User") {
      navigate("/login");
    }

    let booking = {};
    if (bookingString) {
      booking = JSON.parse(bookingString);
      console.log(booking.bookingId);
      setBooking(booking);
      setBookingId(booking.bookingId);
    }
  }, []);

  const handleGenerateTicket = () => {
    axios
      .post(`http://localhost:8080/ticket/${bookingId}`)
      .then((response) => {
        setTicket(response.data);
        setTicketId(response.data.ticketid);
        alert(
          "Congratulations, Ticket reserved successfully. Click on View Ticket Button to Download Ticket"
        );
        console.log(response);
      })
      .catch((error) => {
        alert(
          "Ticket already Generated for this Booking Id. Click View Ticket Button to Download Ticket"
        );
        console.error("Ticket already booked by this bookingId ", error);
      });
  };

  console.log(ticketId);
  const handleViewTicket = () => {
    navigate("/viewTicket", { ticketId });
  };
  return (
    <div className="generate-ticket">
      <LoginNavbar />
      <h2>Journey Details</h2>

      {ticket && (
        <div>
          <h3>Ticket Details</h3>
          <table>
            <tbody>
              {/* <tr>
                <td>Ticket ID:</td>
                <td>{ticketId}</td>
              </tr> */}
              <tr>
                <td>Booking ID:</td>
                <td>{booking.bookingId}</td>
              </tr>
              <tr>
                <td>Train Name:</td>
                <td>{booking?.train?.trainName}</td>
              </tr>
              <tr>
                <td>Source:</td>
                <td>{booking?.train?.source}</td>
              </tr>
              <tr>
                <td>Destination:</td>
                <td>{booking?.train?.destination}</td>
              </tr>
              <tr>
                <td>Journey Date:</td>
                <td>{booking?.train?.journeyDate}</td>
              </tr>
              <tr>
                <td>Arrival Time:</td>
                <td>{booking?.train?.arrivalTime}</td>
              </tr>
              <tr>
                <td>Departure Time:</td>
                <td>{booking?.train?.departureTime}</td>
              </tr>
              <tr>
                <td>Total Tickets:</td>
                <td>{booking?.totalTickets}</td>
              </tr>
              <tr>
                <td>Total Fare:</td>
                <td>{booking?.totalFare}</td>
              </tr>
            </tbody>
          </table>
          <div className="ticket-btn">
            <button onClick={handleGenerateTicket}>Generate Ticket</button>

            <button onClick={handleViewTicket}>View Ticket</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default GenerateTicket;
