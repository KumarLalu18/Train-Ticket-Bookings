import React, { useState, useEffect } from 'react';
import axios from 'axios';

import AdminLoginNavbar from '../LoginNavbar/AdminNavbar';

function ViewBooking() {
  const [bookingData, setBookingData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/bookings')
      .then(res => {
        setBookingData(res.data);
      })
      .catch(err => {
        console.log(err);
      });
  }, []);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:8080/bookings/${id}`)
      .then(res => {
        setBookingData(bookingData.filter(booking => booking.bookingId !== id));
        alert("Booking deleted successfully");
      })
      .catch(err => {
        console.log(err);
        alert("Error deleting Booking");
      });
  };

  return (
    <div>
      <AdminLoginNavbar />
      <table className="booking-table">
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Train ID</th>
            <th>Train Name</th>
            <th>Train Type</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Journey Date</th>
            <th>Arrival Time</th>
            <th>Departure Time</th>
            <th>Fare</th>
            <th>Available Seats</th>
            <th>Total Seats</th>
            <th>Total Fare</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {bookingData.map((booking) => (
            <tr key={booking.bookingId}>
              <td>{booking.bookingId}</td>
              <td>{booking.train.trainId}</td>
              <td>{booking.train.trainName}</td>
              <td>{booking.train.trainType}</td>
              <td>{booking.train.source}</td>
              <td>{booking.train.destination}</td>
              <td>{booking.train.journeyDate}</td>
              <td>{booking.train.arrivalTime}</td>
              <td>{booking.train.departureTime}</td>
              <td>{booking.train.fare}</td>
              <td>{booking.train.availableSeats}</td>
              <td>{booking.train.totalSeats}</td>
              <td>{booking.totalFare}</td>
              <td>
                <button onClick={() => handleDelete(booking.bookingId)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ViewBooking;