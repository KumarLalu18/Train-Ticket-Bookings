import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; 
import './CreateBooking.css';
import LoginNavbar from '../LoginNavbar/LoginNavbar';

function CreateBooking() {
  const navigate = useNavigate(); 

  
  useEffect(() => {
    const userString = localStorage.getItem('user');
    if (!userString) {
      navigate('/login');
      return;
    }
    const user = JSON.parse(userString);
    if (user.role !== 'User') {
      navigate('/login');
    }
  }, [navigate]);

  const [passengers, setPassengers] = useState([
    {
      id: 1,
      name: '',
      age: '',
      gender: '',
    },
  ]);
  const [maxPassengers, setMaxPassengers] = useState(4);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    const userString = localStorage.getItem('user');
    const trainString = localStorage.getItem('train');

    console.log(userString);
    console.log(trainString);
    let user = {};
    let train = {};
    if (userString) {
      user = JSON.parse(userString);
      console.log(user.id);
    }
    if (trainString) {
      train = JSON.parse(trainString);
    }
    if (user.id && train.trainId) {
      console.log(passengers);
      console.log(user.id);
      console.log(train.trainId);

      const passengersData = passengers.map((passenger) => ({
        name: passenger.name,
        age: passenger.age,
        gender: passenger.gender,
      }));

      // Set passengers data in local storage
      localStorage.setItem('passengers', JSON.stringify(passengersData));

      axios
        .post(`http://localhost:8080/bookings/${train.trainId}/${user.id}`, passengersData)
        .then((booking) => {
          console.log('booking response ', booking);
          alert('Passenger Details Added successfully');
          
          localStorage.setItem('booking', JSON.stringify(booking.data));
          localStorage.setItem('passengers', JSON.stringify(passengersData));

          // Set submitted
          setSubmitted(true);
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      console.log('userId or trainId not found in localstorage');
    }
  };

  const handlePassengerChange = (event, index) => {
    const { name, value } = event.target;
    const newPassengers = [...passengers];
    if (name === 'age') {
      const age = parseInt(value, 10);
      if (isNaN(age)) {
        alert('Invalid age');
        return;
      }
      newPassengers[index].age = age;
    } else {
      newPassengers[index][name] = value;
    }
    setPassengers(newPassengers);
  };

  const handleAddPassenger = (event) => {
    event.preventDefault();
    if (passengers.length < maxPassengers) {
      setPassengers([
        ...passengers,
        {
          id: passengers.length + 1,
          name: '',
          age: '',
          gender: '',
        },
      ]);
    } else {
      alert('Maximum number of passengers reached.');
    }
  };

  const handleDeletePassenger = (id) => {
    axios
      .delete(`http://localhost:8080/bookings/deletePassById/${id}`)
      .then((response) => {
        console.log('Deletion response: ',response);
        setPassengers((prevState) => prevState.filter((passenger) => passenger.id !== id));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleBookingDetails = () => {
    if (submitted) {
      // Navigate to BookingDetails page
      alert("Go for Confirm Resevation?");
      navigate('/booking-details');
    } else {
      alert('Please, Submit added passengers');
    }
  };

  return (
    <div>
      <LoginNavbar />
      <div className="createbooking">
        <form onSubmit={handleSubmit} className="passenger-form">
          {passengers.map((passenger, index) => (
            <div className="pass" key={index}>
              <label>
                Passenger {index + 1}:
                <input
                  type="text"
                  name="name"
                  placeholder="Passenger Name"
                  value={passenger.name}
                  onChange={(event) => handlePassengerChange(event, index)}
                  required
                />
                <input
                  type="number"
                  name="age"
                  placeholder="Enter Age"
                  min={0}
                  value={passenger.age}
                  onChange={(event) => handlePassengerChange(event, index)}
                  required
                />
                <select
                  name="gender"
                  value={passenger.gender}
                  onChange={(event) => handlePassengerChange(event, index)}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </label>
            </div>
          ))}
          <button onClick={handleAddPassenger} className="add-passenger-btn">
            Add Passenger
          </button>
          <p>Current number of passengers: {passengers.length}</p>
          <input type="submit" value="Submit" className="submit-btn" />
          <button onClick={handleBookingDetails} className="book-btn">
            Book
          </button>
        </form>
        <div className="passlist">
          <h1>Passenger List</h1>
          <table className="passengertable">
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {passengers.map((passenger, index) => (
                <tr key={index}>
                  <td>{passenger.name}</td>
                  <td>{passenger.age}</td>
                  <td>{passenger.gender}</td>
                  <td>
                    <button
                      onClick={() => handleDeletePassenger(passenger.id)}
                      className="delete-btn"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default CreateBooking;