
import React from 'react';
 

function Footer() {
  return (
    <div style={footerStyle.container}>
      <nav className="navbar navbar-dark" style={footerStyle.bg}>
        <div className="container-fluid">
          <span className="navbar-text">
          © 2024 RailX. All rights reserved.
          </span>
        </div>
      </nav>
    </div>
  );
};
 
let footerStyle = {
  container: {
    position: 'fixed',
    bottom: 0,
    width: '100%',
    height: '30px', // adjust the height as needed
    backgroundColor: 'gray',
    color: '#fff',
    textAlign: 'center',
    padding: '10px',
    
  },
  bg: {
    background: 'gray',
  },
};
 
export default Footer;