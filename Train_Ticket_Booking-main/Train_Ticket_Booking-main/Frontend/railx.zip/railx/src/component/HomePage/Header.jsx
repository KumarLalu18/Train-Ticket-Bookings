import React from "react";
import { Link } from "react-router-dom";
import "./HomePage.css"; // Make sure the CSS file is imported in the new component
import train_logo from "../Assets/train.png";

function Header() {
  return (
    <header>
      <nav>
        <Link to="/" className="image-link">
          <img
            // src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR17QvBiBxZiUQ8T293cvuflIfD47PLe-anAA&usqp=CAU"
            src={train_logo}
            alt="RailX Logo"
          />
        </Link>

        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/searchTrain">Search Train</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
          <li>
            <Link to="/signup">Register</Link>
          </li>

          <li>
            <Link to="/login">Admin Login</Link>
          </li>

          <li>
            <Link to="/about">About</Link>
          </li>
          {/* <li>
            <Link to="/contact">Contact</Link>
          </li> */}
        </ul>
      </nav>
    </header>
  );
}

export default Header;
