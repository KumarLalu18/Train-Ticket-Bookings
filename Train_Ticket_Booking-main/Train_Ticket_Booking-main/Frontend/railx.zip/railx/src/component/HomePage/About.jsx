import React from 'react';
import LoginNavbar from '../LoginNavbar/LoginNavbar';
import './About.css';

const About = () => {
  return (
    <>        <LoginNavbar/>
    <div className="about-page">
      <h2>About Us</h2>
      <p>
        Welcome to our train ticket booking platform, where we make your travel experience seamless and enjoyable. Our mission is to provide you with a convenient and efficient way to book train tickets online.
      </p>
      <h3>Our Team</h3>
      <p>
        Our team is composed of experienced developers, designers, and travel industry experts who are passionate about delivering the best possible user experience. We work tirelessly to ensure that our platform is user-friendly, secure, and reliable.
      </p>
      <h3>Contact Us</h3>
      <p>
        If you have any questions, comments, or suggestions, please don't hesitate to contact us. We value your feedback and are always looking for ways to improve our service.
      </p>
      <p>
        Email us at <a href="mailto:info@trainbooking.com">info@railX.com</a> or call us at +XXXXXXXXXXXX.
      </p>
    </div>
    </>

  );
};

export default About;