import React from "react";

import LoginNavbar from "../LoginNavbar/LoginNavbar";
import Header from "./Header";
import "./HomePage.css";
import { useNavigate } from "react-router-dom";
import AdminLoginNavbar from "../LoginNavbar/AdminNavbar";

function HomePage() {
  const user = localStorage.getItem("user");
  const navigate = useNavigate();

  let users = {};

  if (user) {
    users = JSON.parse(user);
  }
  const renderNavbar = () => {
    if (!user) {
      return <Header />;
    }
    switch (users.role) {
      case "User":
        return <LoginNavbar />;
      case "Admin":
        return <AdminLoginNavbar />;
      default:
        return <Header />;
    }
  };

  return (
    <div className="home">
     
      {renderNavbar()}
      <div className="wel">
        <h1>Welcome To RailX...</h1>
        <p>Welcome back! Ready to embark on a new journey?</p>
        <button
          type="button"
          onClick={() =>
            user ? navigate("/createBooking") : navigate("/searchTrain")
          }
        >
          Search Train
        </button>
      </div>
      <div className="trainimage"></div>
    </div>
  );
}

export default HomePage;
