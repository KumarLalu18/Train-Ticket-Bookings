import React, { useState } from 'react';
import axios from 'axios';

import './LoginSignup.css';
import user_icon from '../Assets/person.png';
import passowrd_icon from '../Assets/password.png';
import { useNavigate } from 'react-router-dom';

const LoginSignup = () => {
  const [action, setAction] = useState('Sign Up');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  

  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/user/getlogin', { username, password })
      .then(response => {
        alert("Login successfully");
        console.log(response);
        navigate('/createBooking');
      })
      .catch(error => {
        alert("Invalid");
        console.log(error);
      });
  }

  const handleSignup = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/user/create', { username, password, role })
      .then(response => {
        alert("Registered successfully");
       
        
      })
      .catch(error => {
        alert("Failed to Register!!");
        console.error(error);
      });
  }

  return (
    <div className='container'>
      <div className='header'>
        <div className='text'>
          {action}
        </div>
        <div className='inputs'>
          {action === 'Login' ? (
          
            <form id='login' onSubmit={handleLogin}>
              <div className='input'>
                <img src={user_icon} alt="" />
                <input type="text" placeholder='Username' value={username} onChange={(e) => setUsername(e.target.value) } required />
              </div>
              <div className='input'>
                <img src={passowrd_icon} alt="" />
                <input type="password" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <div className='submit-container'>
                <div className={action === 'Login' ? 'submit' : 'submit gray'} onClick={() => setAction('Sign Up')}>Sign Up</div>
                <button type='submit' className={action === 'Login' ? 'submit' : 'submit gray'}>Login</button>
              </div>
            </form>
          ) : (
            <form id='signup' onSubmit={handleSignup}>
              <div className='input'>
                <img src={user_icon} alt="" />
                <input type="text" placeholder='Name' value={username} onChange={(e) => setUsername(e.target.value)} required/>
              </div>
              <div className='input'>
                <img src={passowrd_icon} alt="" />
                <input type="password" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <div className='input'>
              <img src=' ' alt="" />
                <input type="text" placeholder='Role' value={role} onChange={(e) => setRole(e.target.value)} required />
              </div>
              <div className='submit-container'>
                <div className={action === 'Login' ? 'submit gray' : 'submit'} onClick={() => setAction('Login')}>Login</div>
                <button type='submit' className={action === 'Sign Up' ? 'submit' : 'submit gray'}>Sign Up</button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginSignup;