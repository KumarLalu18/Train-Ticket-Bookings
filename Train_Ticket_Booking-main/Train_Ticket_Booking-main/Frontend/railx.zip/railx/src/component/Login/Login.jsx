import React, { useState } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import "./Login.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogin = async (username, password) => {
    try {
      const response = await axios.post("http://localhost:8080/user/getlogin", { username, password });
      const userData = response.data;
      if (userData && userData.id) {
        localStorage.setItem("user", JSON.stringify(userData));
        const user = JSON.parse(localStorage.getItem("user"));
        if (user.role === "Admin") {
          alert("Admin Login Successfully")
          navigate("/viewTrain");
        } else {
          const train = location.state && location.state.train;
          if (train) {
            alert("User Login Successfully")
            navigate("/createBooking", { state: { train } });
          } else {
            alert("User Login Successfully")
            navigate("/searchTrain");
          }
        }
      } else {
        setError("Invalid username or password");
      }
    } catch (error) {
      console.error("There was an error!", error);
      setError("An error occurred. Please try again.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmedUsername = username.trim();
    if (trimmedUsername && password) {
      handleLogin(trimmedUsername, password);
    } else {
      setError("Please enter both username and password");
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <div className="login">
        <form onSubmit={handleSubmit}>
          <label>
            Username:
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </label>
          <label>
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <p>
              Don't have an account?{" "}
              <span
                onClick={() => navigate("/signup")}
                style={{ color: "blue", cursor: "pointer" }}
              >
                Register
              </span>
            </p>
          </label>
          {error && <div style={{ color: "red" }}>{error}</div>}
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;