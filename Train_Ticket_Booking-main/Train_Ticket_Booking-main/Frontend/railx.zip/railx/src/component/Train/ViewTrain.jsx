import './ViewTrain.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

import AdminLoginNavbar from '../LoginNavbar/AdminNavbar';

function ViewTrain() {
    const [trainData, setTrainData] = useState([]);
    const [selectedTrain, setSelectedTrain] = useState(null);
    const navigate = useNavigate();

    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const isAdmin = user.role === 'Admin';

    useEffect(() => {
        allTrains();
    }, []);

    const allTrains = () => {
        axios.get('http://localhost:8080/train/all')
            .then(res => {
                setTrainData(res.data);
            })
            .catch(err => {
                console.log(err);
            });
    }

    const handleDelete = (trainId) => {
        console.log(trainId);
        axios.delete(`http://localhost:8080/train/delete/${trainId}`)
            .then(res => {
                setTrainData(trainData.filter(train => train.id !== trainId));
                alert("Train deleted successfully");
                allTrains();
            })
            .catch(err => {
                console.log(err);
                alert("Error deleting train");
            });

    }

    const handleUpdate = (trainId) => {
        const trainToUpdate = trainData.find(train => train.trainId === trainId);
        setSelectedTrain(trainToUpdate);

    }

    const handleSave = () => {
        axios.put(`http://localhost:8080/train/update`, selectedTrain)
            .then(res => {
                setTrainData(trainData.map(train => train.trainId === selectedTrain.trainId ? selectedTrain : train));
                setSelectedTrain(null);
                alert("Train updated successfully");
            })
            .catch(err => {
                console.log(err);
                alert("Error updating train");
            });
    }

    function onAddTrain() {
        navigate('/addTrain');
    }

    const handleSelect = (trainId, value) => {
        if (value === 'update') {
            handleUpdate(trainId);
        } else if (value === 'delete') {
            handleDelete(trainId);
        }
    };

    return (
        <>
            <AdminLoginNavbar/>

            {isAdmin ? (
                <>
                    <h1></h1>

                    {!selectedTrain && (
                        <table>
                            <thead>
                                <tr>
                                    <th>Train Id</th>
                                    <th>Train Name</th>
                                    <th>Train Type</th>
                                    <th>Source</th>
                                    <th>Destination</th>
                                    <th>Journey Date</th>
                                    <th>Arrival Time</th>
                                    <th>Departure Time</th>
                                    <th>Fare</th>
                                    <th>Available Seats</th>
                                    <th>Total Seats</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {trainData.map((train, index) => (
                                    <tr key={index}>
                                        <td>{train.trainId}</td>
                                        <td>{train.trainName}</td>
                                        <td>{train.trainType}</td>
                                        <td>{train.source}</td>
                                        <td>{train.destination}</td>
                                        <td>{train.journeyDate}</td>
                                        <td>{train.arrivalTime}</td>
                                        <td>{train.departureTime}</td>
                                        <td>{train.fare}</td>
                                        <td>{train.availableSeats}</td>
                                        <td>{train.totalSeats}</td>
                                        <td>
                                            <select onChange={(event) => handleSelect(train.trainId, event.target.value)}>
                                                <option>Action</option>
                                                <option value="update">Update</option>
                                                <option value="delete">Delete</option>
                                            </select>
                                        </td>

                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}

                    {selectedTrain && (
                        <>
                            <h1>Update Train Details</h1>
                            <form className='updatetrain'>

                                
                                <label htmlFor="trainId">Train Id:</label>
                                <input type="number" id="trainId" name="trainId" value={selectedTrain.trainId} onChange={(e) => setSelectedTrain({ ...selectedTrain, trainId: e.target.value })} /><br />
                                
                                <label htmlFor="trainName">Train Name:</label>
                                <input type="text" id="trainName" name="trainName" value={selectedTrain.trainName} onChange={(e) => setSelectedTrain({ ...selectedTrain, trainName: e.target.value })} /><br />

                                <label htmlFor="trainType">Train Type:</label>
                                <select id="trainType" value={selectedTrain.trainType} onChange={(e) => setSelectedTrain({ ...selectedTrain, trainType: e.target.value })} >
                                    <option value="Select Type" disabled>Select Type</option>
                                    <option value="AC" >AC</option>
                                    <option value="Sleeper">Sleeper</option>

                                </select><br />

                                <label htmlFor="source">Source:</label>
                                <input type="text" id="source" name="source" value={selectedTrain.source} onChange={(e) => setSelectedTrain({ ...selectedTrain, source: e.target.value })} /><br />

                                <label htmlFor="destination">Destination:</label>
                                <input type="text" id="destination" name="destination" value={selectedTrain.destination} onChange={(e) => setSelectedTrain({ ...selectedTrain, destination: e.target.value })} /><br />

                                <label htmlFor="journeyDate">Journey Date:</label>
                                <input type="date" name="trainJourneyDate" value={selectedTrain.journeyDate} onChange={(e) => setSelectedTrain({ ...selectedTrain, journeyDate: e.target.value })} /><br />

                                <label htmlFor="arrivalTime">Arrival Time:</label>
                                <input type="time" id="arrivalTime" name="arrivalTime" value={selectedTrain.arrivalTime} onChange={(e) => setSelectedTrain({ ...selectedTrain, arrivalTime: e.target.value })} /><br />

                                <label htmlFor="departureTime">Departure Time:</label>
                                <input type="time" id="departureTime" name="departureTime" value={selectedTrain.departureTime} onChange={(e) => setSelectedTrain({ ...selectedTrain, departureTime: e.target.value })} /><br />

                                <label htmlFor="fare">Fare:</label>
                                <input type="number" id="fare" name="fare" value={selectedTrain.fare} onChange={(e) => setSelectedTrain({ ...selectedTrain, fare: e.target.value })} /><br />

                                <label htmlFor="availableSeats">Available Seats:</label>
                                <input type="number" id="availableSeats" name="availableSeats" value={selectedTrain.availableSeats} onChange={(e) => setSelectedTrain({ ...selectedTrain, availableSeats: e.target.value })} /><br />

                                <label htmlFor="totalSeats">Total Seats:</label>
                                <input type="number"id="totalSeats" name="totalSeats" min="0" value={selectedTrain.totalSeats} onChange={(e) => setSelectedTrain({ ...selectedTrain, totalSeats: e.target.value })} /><br />

                                <button type="submit" onClick={handleSave}>Save Train</button>
                            </form>
                        </>
                    )}
                </>
            ) : (
                <p>Only Admin can Access This Page</p>
            )}
        </>
    );
}

export default ViewTrain;