import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AdminLoginNavbar from '../LoginNavbar/AdminNavbar';

function PassengerList({ location }) {
  const { state } = location;
  const { selectedTrain } = state || {};
  const [bookings, setBookings] = useState([]);
  let srno = 0; 

  useEffect(() => {
    const fetchBookings = async trainId => {
      try {
        const response = await axios.get(`http://localhost:8080/ticket/getByTrainId/${trainId}`);
        setBookings(response.data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    if (selectedTrain) {
      fetchBookings(selectedTrain.trainId);
    }
  }, [selectedTrain]);

  return (
    <div>
      <AdminLoginNavbar/>
      <h1>Reservation Details </h1>
      <table>
        <thead>
          <tr>
            <th>Train ID</th>
            <th>Train Name</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Journey Date</th>
            <th>Arrival Time</th>
            <th>Departure Time</th>
            <th>Available Seats</th>
            <th>Total Seats</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{selectedTrain && selectedTrain.trainId}</td>
            <td>{selectedTrain && selectedTrain.trainName}</td>
            <td>{selectedTrain && selectedTrain.source}</td>
            <td>{selectedTrain && selectedTrain.destination}</td>
            <td>{selectedTrain && selectedTrain.journeyDate}</td>
            <td>{selectedTrain && selectedTrain.arrivalTime}</td>
            <td>{selectedTrain && selectedTrain.departureTime}</td>
            <td>{selectedTrain && selectedTrain.availableSeats}</td>
            <td>{selectedTrain && selectedTrain.totalSeats}</td>
          </tr>
        </tbody>
      </table>
      <h1>Passengers</h1>
      <table>
        <thead>
          <tr>
            <th>Sr. No.</th>
            <th>Passenger Name</th>
            <th>Age</th>
            <th>Gender</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking, index) => (
            <>
            {booking.booking.passengerDetails.map((passenger, idx) => 
              (
                <tr key={passenger.passengerId}>
                  <td>{++srno}</td>
                  <td>{passenger.name}</td>
                  <td>{passenger.age}</td>
                  <td>{passenger.gender}</td>
                </tr>
              ))}
            </>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PassengerList;