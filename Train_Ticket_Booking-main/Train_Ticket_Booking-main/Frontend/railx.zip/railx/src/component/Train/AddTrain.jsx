import "./AddTrain.css";
import { useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";

import AdminLoginNavbar from "../LoginNavbar/AdminNavbar";

function AddTrain() {
  // Check if user is Admin
  const userString = localStorage.getItem("user");
  let user = {};

  if (userString) {
    user = JSON.parse(userString);
  }
  const isAdmin = user.role === "Admin";

  const [trainName, setTrainName] = useState("");
  const [trainType, setTrainType] = useState("");
  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [journeyDate, setJourneyDate] = useState("");
  const [arrivalTime, setArrivalTime] = useState("");
  const [departureTime, setDepartureTime] = useState("");
  const [fare, setFare] = useState("");
  const [availableSeats, setAvailableSeats] = useState("");
  const [totalSeats, setTotalSeats] = useState("");

  const navigate = useNavigate();

  if (isAdmin) {
    function onsubmit() {
      console.log(trainName);

      // Validate availableSeats is not greater than totalSeats
      if (parseInt(availableSeats) > parseInt(totalSeats)) {
        alert("Available seats should not be greater than total seats.");
        return;
      }

      axios
        .post("http://localhost:8080/train/add", {
          trainName,
          trainType,
          source,
          destination,
          journeyDate,
          arrivalTime,
          departureTime,
          fare,
          availableSeats,
          totalSeats,
        })
        .then((res) => {
          console.log(res);
          alert(" Train Added successfully");
          navigate("/viewTrain");
        });
    }

    return (
      <>
        <AdminLoginNavbar />
        <h1>Add new train</h1>

        <div class="center-div">
          <label htmlFor="trainName">Train Name:</label>
          <input
            type="text"
            id="trainName"
            name="trainName"
            onChange={(e) => setTrainName(e.target.value)}
            required
          />
          <br />

          <label htmlFor="train_type">Train Type:</label>
          <select
            id="train_type"
            onChange={(e) => setTrainType(e.target.value)}
            required
          >
            <option name="train_type">Select Type</option>
            <option name="train_type" value="AC">
              AC
            </option>
            <option name="train_type" value="Sleeper">
              Sleeper
            </option>
          </select>
          <br />

          <label htmlFor="source">Source:</label>
          <input
            type="text"
            id="source"
            name="source"
            onChange={(e) => setSource(e.target.value)}
            required
          />
          <br />

          <label htmlFor="destination">Destination:</label>
          <input
            type="text"
            id="destination"
            name="destination"
            onChange={(e) => setDestination(e.target.value)}
            required
          />
          <br />

          <label htmlFor="journeyDate">Journey Date:</label>
          <input
            type="date"
            name="trainJourneyDate"
            onChange={(e) => setJourneyDate(e.target.value)}
            required
          />
          <br />

          <label htmlFor="arrival_time">Arrival Time:</label>
          <input
            type="time"
            id="arrival_time"
            name="arrival_time"
            onChange={(e) => setArrivalTime(e.target.value)}
            required
          />
          <br />

          <label htmlFor="departure_time">Departure Time:</label>
          <input
            type="time"
            id="departure_time"
            name="departure_time"
            onChange={(e) => setDepartureTime(e.target.value)}
            required
          />
          <br />

          <label htmlFor="fare">Fare:</label>
          <input
            type="number"
            id="fare"
            name="fare"
            min="0"
            onChange={(e) => setFare(e.target.value)}
            required
          />
          <br />
          <label htmlFor="seat">Available Seats:</label>
          <input
            type="number"
            id="availableSeats"
            min="0"
            name="availableSeats"
            onChange={(e) => setAvailableSeats(e.target.value)}
            required
          />
          <br />

          <label htmlFor="totalSeats">Total Seats:</label>
          <input
            type="number"
            id="totalSeats"
            name="totalSeats"
            min="0"
            onChange={(e) => setTotalSeats(e.target.value)}
            required
          />
          <br />

          <button className="addTrainButton" type="submit" onClick={onsubmit}>
            Add
          </button>
        </div>
      </>
    );
  } else {
    return <p>This page is only accessible by Admin.</p>;
  }
}

export default AddTrain;
