import React, { useState } from "react";
import { Link } from "react-router-dom";
import train_logo from "../Assets/train.png";
import './LoginNavbar.css';

function LoginNavbar() {
  const userString = localStorage.getItem("user");
  let user = {};

  if (userString) {
    user = JSON.parse(userString);
  }

  const [dropdown, setDropdown] = useState(false);

  const signOut = () => {
    localStorage.clear();
  };

  return (
    <header>
 <nav>
  <Link to="/" className="image-link">
   <img src={train_logo} alt="RailX Logo" />
  </Link>
  <ul>
   <li> <Link to="/">Home</Link> </li>
   <li> <Link to="/searchTrain">Search Train</Link> </li>
   <li> <Link to="/myReservations">My Reservation</Link> </li>
   <li> <Link to="/about">About</Link> </li>
   <li> <Link to="/contact">Contact</Link> </li>
  </ul>
  <ul>
   {user.username ? (
    <div className="dropdown" onClick={() => setDropdown(!dropdown)}>
     <Link to="#">Welcome {user.username}</Link>
     {dropdown && (
      <div className="dropdown-content">
       <Link to="/" onClick={signOut}>Sign Out</Link>
      </div>
     )}
    </div>
   ) : (
    <Link to="/login">Login / Register</Link>
   )}
  </ul>
 </nav>
</header>
  );
}

export default LoginNavbar;