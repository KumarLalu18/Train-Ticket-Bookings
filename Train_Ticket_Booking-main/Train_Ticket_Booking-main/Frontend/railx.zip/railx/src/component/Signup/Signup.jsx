import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Signup.css';

function Signup() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("User");
  const [usernameError, setUsernameError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      axios.post('http://localhost:8080/user/create', { username, password, role: 'User' })
        .then((res) => {
          console.log(res);
          alert("Registered successfully");
          navigate('/login');
        })
        .catch((error) => {
          console.error('There was an error!', error);
          alert("Registration Failed");
        });
    }
  }

  const validateForm = () => {
    let isValid = true;
    if (username.length < 3) {
      setUsernameError("Username must be at least 3 characters");
      isValid = false;
    } else {
      setUsernameError("");
    }
    if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      isValid = false;
    } else {
      setPasswordError("");
    }
    return isValid;
  }

  return (
    <div>
      <h1>Signup</h1>
      <div className='Signup'>
        <form onSubmit={handleSubmit}>
          <label>
            Username:
            <input
              className='username'
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            {usernameError && <div style={{ color: 'red' }}>{usernameError}</div>}
          </label>
          <label>
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            {passwordError && <div style={{ color: 'red' }}>{passwordError}</div>}
          </label>
          <label>
            Role:
            <input
              className='role'
              type="text"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              required
            />
          </label>
          <button type="submit">Sign Up</button>
        </form>
      </div>
    </div>
  );
};

export default Signup;