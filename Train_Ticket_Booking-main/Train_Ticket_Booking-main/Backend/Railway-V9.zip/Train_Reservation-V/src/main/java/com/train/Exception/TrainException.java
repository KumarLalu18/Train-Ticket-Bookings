package com.train.Exception;

public class TrainException extends Exception {

	    public TrainException(){
	    	
	    }
	    public TrainException(String msg)
	    {
	    	super(msg);
	    }
	
}
